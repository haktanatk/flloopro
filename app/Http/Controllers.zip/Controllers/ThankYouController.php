<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\OrderLine;
use Illuminate\Http\Request;

class ThankYouController extends Controller
{
    public function show(Request $request)
    {
        $orderNo = $request->query('order');
        if (!$orderNo) {
            abort(404, 'Sipariş numarası eksik');
        }

        // Order
        $order = Order::where('order_number', $orderNo)->firstOrFail();

        // Lines (+ ürün adı için products join)
        $lines = OrderLine::leftJoin('products','products.sku','=','order_lines.sku')
            ->where('order_lines.order_id', $order->id)
            ->get([
                'order_lines.sku',
                'order_lines.qty',
                'order_lines.unit_price',
                'order_lines.line_total',
                'products.name as product_name',
            ]);

        return view('pages.thankyou', compact('order','lines'));
        }
}
