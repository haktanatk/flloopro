<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;

class MyOrdersController extends Controller
{
    public function index(Request $request)
    {
        $orders = Order::where('user_id', $request->user()->id)
            ->latest()
            ->paginate(20);

        // Artık pages/orders.blade.php'yi render ediyoruz
        return view('pages.orders', ['orders' => $orders]);

        // İstersen şu şekilde esnek de bırakabilirsin:
        // return view()->first(['pages.orders','pages.order','account.orders'], ['orders' => $orders]);
    }
}
