<?php

namespace App\Http\Controllers;

use App\Models\Basket;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log; // sadece log için

class CheckoutController extends Controller
{
    private function currentBasket(Request $request): Basket
    {
        return Basket::currentFor($request);
    }

    /* ----------------- YARDIMCI: allocations listesini tanı ----------------- */
    private static function looksLikeAllocList(array $list): bool
    {
        if (empty($list) || !isset($list[0]) || !is_array($list[0])) return false;
        foreach ($list as $row) {
            if (!is_array($row)) return false;
            $keys = array_change_key_case(array_keys($row), CASE_LOWER);
            if (!(in_array('sku', $keys, true) && in_array('qty', $keys, true))) return false;
        }
        return true;
    }

    private function extractAllocationsFromResponse(array $res): array
    {
        // Basit BFS: bütün alt dizileri dolaş, [{sku, qty}..] formatını bul
        $q = [$res];
        while ($q) {
            $node = array_shift($q);
            if (is_array($node)) {
                if (self::looksLikeAllocList($node)) {
                    return $node;
                }
                foreach ($node as $v) {
                    if (is_array($v)) $q[] = $v;
                }
            }
        }
        return [];
    }
    /* ----------------------------------------------------------------------- */

    public function confirm(Request $request)
    {
        $validated = $request->validate([
            'customer.full_name' => ['required','string','min:3'],
            'customer.email'     => ['required','email'],
            'customer.phone'     => ['required','string','min:10'],
            'customer.address'   => ['required','string','min:10'],
        ]);
        $customer = $validated['customer'];

        $basket = $this->currentBasket($request);

        // Sepet satırlarını Model üstünden al
        $items = $basket->items()->get(['sku','qty']);
        if ($items->isEmpty()) {
            return response()->json(['success'=>false,'message'=>'Sepet boş'], 400);
        }

        // 1) GO → /api/stock/reserve (eski formatın aynen)
        $reservePayload = json_encode([
            'items' => $items->map(fn($r)=>[
                'sku' => (string)$r->sku,
                'qty' => (int)$r->qty,
            ])->values()->all()
        ], JSON_UNESCAPED_UNICODE);

        $reserveRes = $this->doRequest('http://127.0.0.1:3031/api/stock/reserve', $reservePayload, 'POST');

        // (çok küçük ek) Cevap string ise JSON'a çevir
        if (is_string($reserveRes)) {
            $decoded = json_decode($reserveRes, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                $reserveRes = $decoded;
            }
        }

        if (!is_array($reserveRes) || empty($reserveRes['success'])) {
            return response()->json([
                'success'=>false,
                'message'=>$reserveRes['message'] ?? 'Rezervasyon hatası'
            ], 409);
        }

        // allocations'ı önce bilinen path'lerden dene
        $allocations = $reserveRes['allocations'] ?? [];
        if (empty($allocations) && is_array($reserveRes)) {
            // bulunamadıysa tüm JSON'u gez ve [{sku,qty}..] listesini çek
            $allocations = $this->extractAllocationsFromResponse($reserveRes);
        }

        if (empty($allocations)) {
            Log::warning('reserve_no_allocations', ['response' => $reserveRes]);
            return response()->json(['success'=>false,'message'=>'Allocation boş döndü'], 409);
        }

        // Hızlı fiyat lookup: sku => price
        $prices = DB::table('products')->pluck('price', 'sku');

        try {
            $order = Order::createFromAllocations(
                $basket,
                $allocations,
                $prices->toArray(),
                $customer // <- mevcut yapındaki gibi
            );
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage() ?: 'Sipariş oluşturulamadı',
            ], 422);
        }

        return response()->json([
            'success'      => true,
            'order_id'     => $order->id,
            'order_number' => $order->order_number,
            'total'        => $order->total,
            'split_sources'=> DB::table('shipments')->where('order_id',$order->id)->count(),
        ], 201);
    }
}

