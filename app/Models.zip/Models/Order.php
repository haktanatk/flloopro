<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Order extends Model {
    protected $fillable = ['user_id','basket_id','order_number','status','total', 'customer_name','email','phone','address',];

    public function lines() { return $this->hasMany(OrderLine::class); }

    /**
     * Allocation bilgisine göre siparişi oluşturur ve stokları günceller.
     * $allocations: [['sku'=>..., 'qty'=>..., 'stock_source_id'=>...], ...]
     * $prices: ['SKU001' => 299.99, ...]
     */
    public static function createFromAllocations(Basket $basket, array $allocations, array $prices, array $customer = []): self
    {
        return DB::transaction(function () use ($basket, $allocations, $prices, $customer) {

            /** @var Order $order */
            $order = static::create([
                'user_id'      => $basket->user_id,
                'basket_id'    => $basket->id,
                'order_number' => '100-', // id geldikten sonra güncellenecek
                'status'       => 'new',
                'total'        => 0,
                'customer_name'=> $customer['full_name'] ?? null,
                'email'        => $customer['email'] ?? null,
                'phone'        => $customer['phone'] ?? null,
                'address'      => $customer['address'] ?? null,
            ]);

            $total   = 0.0;
            $sources = [];

            foreach ($allocations as $al) {
                $sku   = (string)($al['sku'] ?? '');
                $qty   = (int)($al['qty'] ?? 0);
                $srcId = (int)($al['stock_source_id'] ?? 0);
                if ($sku === '' || $qty < 1 || $srcId < 1) {
                    continue;
                }

                $unit      = (float)($prices[$sku] ?? 0);
                $lineTotal = $unit * $qty;

                $order->lines()->create([
                    'sku'             => $sku,
                    'qty'             => $qty,
                    'unit_price'      => $unit,
                    'line_total'      => $lineTotal,
                    'stock_source_id' => $srcId,
                ]);

                // PRODUCTS stok düş (korumalı)
                $affected = DB::update(
                    'UPDATE products
                     SET stock_qty = stock_qty - ?
                     WHERE sku = ? AND stock_qty >= ?',
                    [$qty, $sku, $qty]
                );
                if ($affected === 0) {
                    throw new \RuntimeException("Stok yetersiz: {$sku}");
                }

                // INVENTORY: on_hand ↓, reserved ↓
                DB::update(
                    'UPDATE inventory
                     SET on_hand = on_hand - ?, reserved = reserved - ?
                     WHERE sku = ? AND stock_source_id = ?',
                    [$qty, $qty, $sku, $srcId]
                );

                $total += $lineTotal;
                $sources[$srcId] = true;
            }

            // Her kaynak için shipment
            foreach (array_keys($sources) as $srcId) {
                DB::table('shipments')->insert([
                    'order_id'        => $order->id,
                    'stock_source_id' => $srcId,
                    'status'          => 'new',
                    'created_at'      => now(),
                    'updated_at'      => now(),
                ]);
            }

            $order->order_number = '100-' . $order->id;
            $order->total        = $total;
            $order->save();

            // Sepeti kapat
            $basket->status = 'ordered';
            $basket->save();

            return $order;
        });
    }
}
