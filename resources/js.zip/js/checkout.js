// Basit yardımcılar
function isEmail(v){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v||'').trim()); }
function isPhone(v){ return /^[0-9\s()+-]{10,}$/.test(String(v||'').trim()); }

function getCustomerFromForm(){
    return {
        full_name: $('#full_name').val()?.trim(),
        email:     $('#email').val()?.trim(),
        phone:     $('#phone').val()?.trim(),
        address:   $('#address').val()?.trim(),
    };
}

function validateCustomer(c){
    const errors = {};
    if(!c.full_name || c.full_name.length < 3) errors.full_name = 'Ad Soyad en az 3 karakter olmalı';
    if(!c.email || !isEmail(c.email))          errors.email     = 'Geçerli bir e-posta giriniz';
    if(!c.phone || !isPhone(c.phone))          errors.phone     = 'Geçerli bir telefon giriniz';
    if(!c.address || c.address.length < 10)    errors.address   = 'Adres en az 10 karakter olmalı';
    return errors;
}

// Inline hata göstermek istersen çok basit bir alert kullanıyoruz (istersen geliştiririz)
function showErrors(errors){
    const msgs = Object.values(errors);
    if(msgs.length){ alert('Lütfen formu kontrol edin:\n- ' + msgs.join('\n- ')); }
}

$(document).on('click', '#btn-order-confirm', function () {
    const $btn = $(this).prop('disabled', true).text('Kontrol ediliyor...');
    const customer = getCustomerFromForm();
    const errs = validateCustomer(customer);

    if(Object.keys(errs).length){
        showErrors(errs);
        $btn.prop('disabled', false).text('Siparişi Onayla');
        return;
    }

    $.ajax({
        url: '/checkout/confirm',
        method: 'POST',
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            'Accept':'application/json',
            'Content-Type':'application/json' },
        data: JSON.stringify({ customer }), // 👈 müşteri bilgilerini da gönderiyoruz
        success: function(res){
            if(res && res.success){
                window.location = '/tesekkur?order=' + encodeURIComponent(res.order_number);
            } else {
                alert('Hata: ' + (res?.message || 'Bilinmeyen hata'));
                $btn.prop('disabled', false).text('Siparişi Onayla');
            }
        },
        error: function(xhr){
            const res = xhr.responseJSON || {};
            alert('Hata: ' + (res.message || 'Bilinmeyen hata'));
            $btn.prop('disabled', false).text('Siparişi Onayla');
        }
    });
});
